import xbmcaddon
import base64

MainBase = 'aHR0cHM6Ly9nb28uZ2wvZ2hnOTky'.decode('base64')
addon = xbmcaddon.Addon('plugin.video.pt.docs.hd')