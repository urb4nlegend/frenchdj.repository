import xbmcaddon
import base64

MainBase = 'aHR0cDovL3B0ZG9jc2hkLnBlLmh1L1BULkRvY1MuSEQueG1s'.decode('base64')
addon = xbmcaddon.Addon('plugin.video.pt.docs.hd')

