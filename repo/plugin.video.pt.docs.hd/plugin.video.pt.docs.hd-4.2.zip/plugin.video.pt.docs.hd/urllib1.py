import xbmcaddon
import base64

MainBase = 'aHR0cHM6Ly9nb28uZ2wvaE5sdDBU'.decode('base64')
addon = xbmcaddon.Addon('plugin.video.pt.docs.hd')