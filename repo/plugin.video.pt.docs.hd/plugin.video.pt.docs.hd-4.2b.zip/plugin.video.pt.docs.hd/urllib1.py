import xbmcaddon
import base64

MainBase = 'aHR0cHM6Ly9nb28uZ2wvclE0NVpU'.decode('base64')
addon = xbmcaddon.Addon('plugin.video.pt.docs.hd')