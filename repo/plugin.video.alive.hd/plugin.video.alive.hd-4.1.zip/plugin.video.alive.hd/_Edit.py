import xbmcaddon
import base64

MainBase = 'aHR0cDovL2FsaXZlaGQucGUuaHUvQWxpdmUuSEQueG1s'.decode('base64')
addon = xbmcaddon.Addon('plugin.video.alive.hd')

