import xbmcaddon
import base64

MainBase = 'aHR0cHM6Ly9nb28uZ2wvdVB4cERl'.decode('base64')
addon = xbmcaddon.Addon('plugin.video.alive.hd')